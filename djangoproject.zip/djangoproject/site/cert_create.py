from django.http import HttpResponseRedirect
from django.shortcuts import render

from djangoproject.site.mysite.testik.models import Certificate


def edit_certificate(request, certificate_id):
    certificate = Certificate.objects.get(id=certificate_id)
    if request.method == 'POST':
        certificate.user_id = request.POST['user_id']
        certificate.certificate_name = request.POST['certificate_name']
        certificate.expiry_date = request.POST['expiry_date']
        certificate.save()
        return HttpResponseRedirect('/success/')  # Redirect to a success page
    else:
        return render(request, 'edit_certificate.html', {'certificate': certificate})