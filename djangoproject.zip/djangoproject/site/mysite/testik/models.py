from django.db import models
from django.contrib.auth.models import User

from djangoproject.site.mysite.anketa.models import Naviki


class Answers(models.Model):
    title = models.TextField(max_length=50, verbose_name="Название")
    users = models.ForeignKey(User, on_delete=models.PROTECT, verbose_name="Пользователь", related_name="SkillsUser")
    skills = models.ForeignKey(Naviki, on_delete=models.PROTECT, verbose_name="Навык", related_name="SkillsAns")
    score = models.PositiveIntegerField()
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-title"]
        verbose_name = "Ответ"
        verbose_name_plural = "Ответы"

    def __str__(self):
        return self.title

    def get_fields(self):
        return [(field.name, field.value_to_string(self))
                for field in Answers._meta.fields]


class Certificate(models.Model):
    user_id = models.IntegerField()
    certificate_name = models.CharField(max_length=100)
    expiry_date = models.DateField()

    class Meta:
        ordering = ["-title"]
        verbose_name = "Сертификат"
        verbose_name_plural = "Сертификаты"

    def __str__(self):
        return self.title

    def get_fields(self):
        return [(field.name, field.value_to_string(self))
                for field in Certificate._meta.fields]
