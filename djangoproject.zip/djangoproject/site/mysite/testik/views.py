from django.shortcuts import render
from .models import Certificate


def create_certificate(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        certificate_name = request.POST.get('certificate_name')
        expiry_date = request.POST.get('expiry_date')
        certificate = Certificate(user_id=user_id, certificate_name=certificate_name, expiry_date=expiry_date)
        certificate.save()
        return render(request, 'certificate_created.html')
    else:
        return render(request, 'create.html')


def delete_certificate(request):
    if request.method == 'POST':
        certificate_id_to_delete = request.POST.get('certificate_id_to_delete')
        certificate = Certificate.objects.get(id=certificate_id_to_delete)
        certificate.delete()
        return render(request, 'certificate_deleted.html')
    else:
        return render(request, 'delete.html')


def edit_certificate(request):
    if request.method == 'POST':
        certificate_id = request.POST.get('certificate_id')
        new_certificate_name = request.POST.get('new_certificate_name')
        new_expiry_date = request.POST.get('new_expiry_date')
        certificate = Certificate.objects.get(id=certificate_id)
        certificate.certificate_name = new_certificate_name
        certificate.expiry_date = new_expiry_date
        certificate.save()
        return render(request, 'certificate_updated.html')
    else:
        return render(request, 'update.html')
