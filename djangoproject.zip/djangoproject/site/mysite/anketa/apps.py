from django.apps import AppConfig


class AnketaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mysite.anketa'
    verbose_name ='Анкетирование'